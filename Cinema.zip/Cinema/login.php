<?php
session_start();

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cinema";

$email = test_input($_POST['email']);
$pw = sha1(test_input($_POST['pw']));

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Έλεγχος για υπάρχον χρήστη
$sql = "SELECT * FROM users WHERE email='$email' AND pw='$pw'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Ο χρήστης υπάρχει, αποθηκεύουμε το όνομα στο session
    $row = $result->fetch_assoc();
    $_SESSION['user_name'] = $row['fname']; // Αποθήκευση του ονόματος χρήστη
    $_SESSION['user_id'] = $row['u_id'];
    $_SESSION['user_role'] = $row['role'];
    header('Location: main.php'); // Μεταφορά στη main.php
    exit;
} else {
    // Αποτυχία σύνδεσης
    header('Location: loginSite.php?status=error');
    exit;
}

$conn->close();
?>


