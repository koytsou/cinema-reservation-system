<?php
session_start();

// Ελέγχει αν ο χρήστης είναι admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    die("Δεν έχετε δικαίωμα πρόσβασης σε αυτήν τη σελίδα.");
}

// Σύνδεση στη βάση δεδομένων
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cinema";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Παίρνει δεδομένα από τη φόρμα
$title = $_POST['title'];
$description = $_POST['description'];
$category = $_POST['category'];
$trailer = $_POST['trailer'];

// Επεξεργασία της εικόνας του `image_url`
$image_url = null;
if (isset($_FILES['image_url']) && $_FILES['image_url']['error'] == 0) {
    $image_url = addslashes(file_get_contents($_FILES['image_url']['tmp_name']));
}

// Επεξεργασία της εικόνας του `rating`
$rating = null;
if (isset($_FILES['rating']) && $_FILES['rating']['error'] == 0) {
    $rating = addslashes(file_get_contents($_FILES['rating']['tmp_name']));
}

// Εισαγωγή δεδομένων στον πίνακα
$sql = "INSERT INTO movies (title, description, image_url, rating, category, trailer) 
        VALUES ('$title', '$description', '$image_url', '$rating', '$category', '$trailer')";

if ($conn->query($sql) === TRUE) {
    // Επιστροφή με μήνυμα επιτυχίας
    header("Location: admin.php?status=success");
    exit();
} else {
    // Επιστροφή με μήνυμα αποτυχίας
    header("Location: admin.php?status=error");
    exit();
}

$conn->close();
?>
