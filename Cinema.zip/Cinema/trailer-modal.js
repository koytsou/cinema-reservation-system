 function showTrailer() {
            document.getElementById('trailer-modal').style.display = 'flex';
        }

        function closeTrailer() {
            var modal = document.getElementById('trailer-modal');
            modal.style.display = 'none';
            var video = document.getElementById('trailer-video');
            if (video.tagName === 'IFRAME') {
                video.src = video.src; // Επανεκκίνηση του YouTube βίντεο
            } else {
                video.pause(); // Παύση του τοπικού βίντεο
                video.currentTime = 0; // Επαναφορά στην αρχή
            }
        }

        // Κλείσιμο του modal όταν ο χρήστης κάνει κλικ έξω από αυτό
        window.onclick = function(event) {
            var modal = document.getElementById('trailer-modal');
            if (event.target == modal) {
                closeTrailer();
            }
        }
       
    function showReservationModal() {
        document.getElementById('reservationModal').style.display = 'block';
    }

    function closeReservationModal() {
        document.getElementById('reservationModal').style.display = 'none';
    }



        
