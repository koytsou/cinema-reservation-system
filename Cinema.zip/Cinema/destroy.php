<?php
session_start();// διαγραφή όλων των session variables
 
session_destroy(); 
header('Location: loginSite.php');
exit;
?>