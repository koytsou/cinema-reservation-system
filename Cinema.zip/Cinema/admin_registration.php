<?php
function test_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cinema";

$fname = test_input($_POST['fname']);
$lname = test_input($_POST['lname']);
$email = test_input($_POST['email']);
$pw = sha1(test_input($_POST['pw']));
$tel = test_input($_POST['tel']);
$role = 'admin'; // Ή test_input($_POST['role']) αν έρχεται από φόρμα

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO users (fname, lname, email, pw, tel, role)
        VALUES ('$fname', '$lname', '$email', '$pw', '$tel', '$role')";

if ($conn->query($sql) === TRUE) {
    header('Location: registerAdminSite.php?status=success');
} else {
    header('Location: registerAdminSite.php?status=error');
}

$conn->close();
?>
