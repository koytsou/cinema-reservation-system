
<?php
session_start();
?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Cinema</title>
    <link rel="stylesheet" href="Css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .user-image {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-bottom: 5px;
        }

        .red-box {
            color: white;
            background-color: red;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .loginborder {
            border: 1px solid red;
        }       
    </style>
    
</head>
  <body class="contact-page blur ">
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CinemaVenia</label>
        <ul>
            <li><a class="active" href="main.php">Aρχική</a></li>
            <li><a href="Ταινιες.php">Ταινιες</a></li>
            <li><a href="Προσεχως.php">Προσεχως</a></li>
            <li><a href="Επικοινωνια.php">Επικοινωνια</a></li>
            <?php
            // Έλεγχος αν ο χρήστης είναι admin
            if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
                echo '<li><a href="admin.php" ">Admin Panel</a></li>';
            }
            ?>
             <?php
            
            if (isset($_SESSION['user_name'])) {
                echo '<li class="user-profile">
                    <img src="images/userprofile.png" alt="User Image" class="user-image">
                    <span>' . $_SESSION['user_name'] . '</span>
                    </li>';
                echo '<li><a href="destroy.php" class="red-box">Logout</a></li>';
            } else {
                echo '<li><a class="red-box loginborder" href="loginSite.php">Login</a></li>';
            }
            ?>
        </ul>
    </nav>
    <div class="contact"><br><br>
        <h1>Επικοινωνία</h1>
        <p>
            Στη σελίδα "Επικοινωνία" μπορείτε να επικοινωνήσετε μαζί μας για οποιαδήποτε απορία ή πρόταση. 
            Στόχος μας είναι να σας παρέχουμε την καλύτερη κινηματογραφική εμπειρία!
        </p><br><br><br>
    </div>
    <div class="split-section">
        <!-- Left side: Contact Information -->
        
        <div class="contact-info">
            <h2>Πληροφορίες Επικοινωνίας</h2>
            <p>
                <img src="Images/location.png" alt="Address Icon" class="icon">
                <strong>Διεύθυνση:</strong> Κεντρική Οδός 123, Αθήνα
            </p>
            <p>
                <img src="Images/email-address.png" alt="Email Icon" class="icon">
                <strong>Email:</strong> info@cinema.gr
            </p>
            <p>
                <img src="Images/phone-call.png" alt="Phone Icon" class="icon">
                <strong>Τηλέφωνο:</strong> 210-123-4567
            </p>
        </div>
        <!-- Right side: Contact Form -->
        <div class="contact-form">
            <h2>Στείλτε μας Μήνυμα</h2>
            <form action="#" method="POST">
                <label for="name">Όνομα:</label>
                <input type="text" id="name" name="name" placeholder="Εισάγετε το όνομά σας" required>
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Εισάγετε το email σας" required>
                
                <label for="message">Μήνυμα:</label>
                <textarea id="message" name="message" placeholder="Γράψτε το μήνυμά σας" rows="5" required></textarea>
                
                <button type="submit">Αποστολή</button>
            </form>
        </div>
    </div>
    
  </body>
</html>