<?php
// Σύνδεση στη βάση δεδομένων
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cinema";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Παίρνει δεδομένα από τη φόρμα
$title = $_POST['title'];
$description = $_POST['description'];
$category = $_POST['category'];
$trailer = $_POST['trailer'];

// Επεξεργασία των εικόνων
$image_url = null;
if (isset($_FILES['image_url']) && $_FILES['image_url']['error'] == 0) {
    $image_url = addslashes(file_get_contents($_FILES['image_url']['tmp_name']));
}

$rating = null;
if (isset($_FILES['rating']) && $_FILES['rating']['error'] == 0) {
    $rating = addslashes(file_get_contents($_FILES['rating']['tmp_name']));
}

// Εισαγωγή δεδομένων στον πίνακα Shortly
$sql = "INSERT INTO shortly (title, description, image_url, rating, category, trailer) 
        VALUES ('$title', '$description', '$image_url', '$rating', '$category', '$trailer')";

if ($conn->query($sql) === TRUE) {
    // Επιστροφή με μήνυμα επιτυχίας
    header("Location: admin.php?status=success");
    exit();
} else {
    // Επιστροφή με μήνυμα αποτυχίας
    header("Location: admin.php?status=error");
    exit();
}

$conn->close();
?>
