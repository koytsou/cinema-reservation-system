<?php

session_start();

// Στοιχεία σύνδεσης με τη βάση δεδομένων
$host = 'localhost';
$dbname = 'cinema';
$username = 'root';
$password = ''; // Βάλε τον κωδικό σου, αν υπάρχει

try {
    // Δημιουργία σύνδεσης με PDO
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // SQL για ανάκτηση δεδομένων
    $stmt = $conn->prepare("SELECT * FROM movies");
    $stmt->execute();

    // Αποθήκευση αποτελεσμάτων
    $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Cinema</title>
    <link rel="stylesheet" href="Css/style.css">
    <link rel="stylesheet" href="Css/StyleForDynamicMovies.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .user-image {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-bottom: 5px;
        }

        .red-box {
            color: white;
            background-color: red;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .loginborder {
            border: 1px solid red;
        }
        h2{
            font-weight: bold; 
            margin-bottom: 18%;
            
        }

    </style>
    
</head>
  <body class="contact-page blur ">
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CinemaVenia</label>
        <ul>
            <li><a class="active" href="main.php">Aρχική</a></li>
            <li><a href="Ταινιες.php">Ταινιες</a></li>
            <li><a href="Προσεχως.php">Προσεχως</a></li>
            <li><a href="Επικοινωνια.php">Επικοινωνια</a></li>
            <?php
            // Έλεγχος αν ο χρήστης είναι admin
            if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
                echo '<li><a href="admin.php" ">Admin Panel</a></li>';
            }
            ?>
             <?php
          
            if (isset($_SESSION['user_name'])) {
                echo '<li class="user-profile">
                    <img src="images/userprofile.png" alt="User Image" class="user-image">
                    <span>' . $_SESSION['user_name'] . '</span>
                    </li>';
                echo '<li><a href="destroy.php" class="red-box">Logout</a></li>';
            } else {
                echo '<li><a class="red-box loginborder" href="loginSite.php">Login</a></li>';
            }
            ?>
        </ul>
    </nav>
    <div class="contact">
        <h1><br>Ταινιες που παίζονται τώρα</h1>
    </div>  
    
        
               <div class="movies">
                        <?php foreach ($movies as $movie): ?>
                            <div class="movie-item">
                                <!-- Εικόνα ταινίας -->
                                <img class="movie-image" src="data:image/jpeg;base64,<?= base64_encode($movie['image_url']) ?>" alt="<?= $movie['title'] ?>" />

                                <!-- Περιεχόμενο -->
                                <div class="movie-content">
                                    <div class="movie-header">
                                        <!-- Τίτλος -->
                                        <h2 class="movie-title"><?= $movie['title'] ?></h2>

                                        <!-- Rating -->
                                        <img class="movie-rating" src="data:image/jpeg;base64,<?= base64_encode($movie['rating']) ?>" alt="Rating" />
                                    </div>

                                    <!-- Περιγραφή -->
                                    <p class="movie-description"><?= $movie['description'] ?></p>

                                    <!-- Κατηγορίες -->
                                    <p class="movie-category"><strong>Κατηγορίες:</strong> <?= $movie['category'] ?></p>
                                    
                                    <a href="Movie.php?id=<?= $movie['id'] ?>" class="link-btn">Δες περισσότερα</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                </div>
   
  </body>
</html>