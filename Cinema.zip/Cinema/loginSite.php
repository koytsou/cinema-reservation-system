<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>CinemaVenia - Login</title>
    <link rel="stylesheet" href="Css/style.css">
    <style>
                .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .user-image {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-bottom: 5px;
        }

        .red-box {
            color: white;
            background-color: red;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .loginborder {
            border: 1px solid red;
        }
    </style>
</head>
<body class="blur">
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CinemaVenia</label>
        <ul>
            <li><a class="active" href="main.php">Aρχική</a></li>
            <li><a href="Ταινιες.php">Ταινιες</a></li>
            <li><a href="Προσεχως.php">Προσεχως</a></li>
            <li><a href="Επικοινωνια.php">Επικοινωνια</a></li>
             <?php
            session_start();
            if (isset($_SESSION['user_name'])) {
                echo '<li class="user-profile">
                    <img src="images/userprofile.png" alt="User Image" class="user-image">
                    <span>' . $_SESSION['user_name'] . '</span>
                    </li>';
                echo '<li><a href="destroy.php" class="red-box">Logout</a></li>';
            } else {
                echo '<li><a class="red-box loginborder" href="loginSite.php">Login</a></li>';
            }
            ?>
        </ul>
    </nav>
    <div class="login-container">
        <div class="login-form">
            <h2>Login <img style="width: 15%;" src="Images/LOGIN.webp"></h2>
            <?php
            if (isset($_GET['status']) && $_GET['status'] === 'error') {
                echo '<p style="color: red;">Λάθος email ή κωδικός. Προσπαθήστε ξανά.</p>';
            }
            ?>
            <form action="login.php" method="POST">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Εισάγετε το email σας" required>

                <label for="password">Κωδικός:</label>
                <input type="password" id="pw" name="pw" placeholder="Εισάγετε τον κωδικό σας" required>

                <button type="submit">Login</button>
            </form>
            <p>Εάν δεν είστε μέλος ακόμα, <a href="registerSite.php">εγγραφείτε εδώ</a>.</p>
        </div>
    </div>
</body>
</html>
