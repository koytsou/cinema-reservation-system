<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: main.php");
    exit;
}

include 'db_connection.php'; // σύνδεση με τη βάση

if (isset($_GET['id'])) {
    $shortly_id = intval($_GET['id']);
    $sql = "DELETE FROM shortly WHERE id = $shortly_id";
    if (mysqli_query($conn, $sql)) {
        header("Location: admin.php?shortly_deleted=1");
    } else {
        echo "Σφάλμα κατά τη διαγραφή: " . mysqli_error($conn);
    }
}
?>
