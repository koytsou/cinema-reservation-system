<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Cinema</title>
    <link rel="stylesheet" href="Css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .user-image {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-bottom: 5px;
        }

        .red-box {
            color: white;
            background-color: red;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .loginborder {
            border: 1px solid red;
        }       
       
    </style>
    
</head>
  <body class="blur">
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CinemaVenia</label>
        <ul>
            <li><a class="active" href="main.php">Aρχική</a></li>
            <li><a href="Ταινιες.php">Ταινιες</a></li>
            <li><a href="Προσεχως.php">Προσεχως</a></li>
            <li><a href="Επικοινωνια.php">Επικοινωνια</a></li>
             <?php
            session_start();
            if (isset($_SESSION['user_name'])) {
                echo '<li class="user-profile">
                    <img src="images/userprofile.png" alt="User Image" class="user-image">
                    <span>' . $_SESSION['user_name'] . '</span>
                    </li>';
                echo '<li><a href="destroy.php" class="red-box">Logout</a></li>';
            } else {
                echo '<li><a class="red-box loginborder" href="loginSite.php">Login</a></li>';
            }
            ?>
        </ul>
    </nav>
    <div class="registration-form">
        <h2>Εγγραφή Admin <img style ="width: 15% ; "src="Images/LOGIN.webp"></h2>
        <span class="close-btn" onclick="window.location.href='main.html'">&times;</span>
        <form action="admin_registration.php" method="POST">
            <label for="firstname">Όνομα:</label>
            <input type="text" id="firstname" name="fname" placeholder="Εισάγετε το όνομά σας" required>

            <label for="lastname">Επώνυμο:</label>
            <input type="text" id="lastname" name="lname" placeholder="Εισάγετε το επώνυμό σας" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Εισάγετε το email σας" required>

            <label for="password">Κωδικός:</label>
            <input type="password" id="password" name="pw" placeholder="Εισάγετε τον κωδικό σας" required>

            <label for="phone">Τηλέφωνο:</label>
            <input type="tel" id="phone" name="tel" placeholder="Εισάγετε τον αριθμό τηλεφώνου σας" required>

            
            <input type="hidden" name="role" value="admin">

            <button type="submit">Εγγραφή Admin</button>
        </form>

        <p>Εάν έχετε ήδη λογαριασμό, <a href="loginSite.php">πατήστε εδώ για να συνδεθείτε</a>.</p>
    </div>
    <div class="content" >
      <h1 style="text-align: left;">Bλεπουμε Ταινιες Μαζί!</h1>
      <p style="text-align: left;"> Ελατε στον μεγευτικο συνεμα μας για να απολαυσετε καθε ταινια στην μεγιστη εμπειρια της </p>
  </div>
  </body>
</html>