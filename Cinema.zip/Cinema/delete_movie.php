<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: main.php");
    exit;
}

include 'db_connection.php'; // κάνε include το αρχείο σύνδεσης με τη βάση

if (isset($_GET['id'])) {
    $movie_id = intval($_GET['id']);
    $sql = "DELETE FROM movies WHERE id = $movie_id";
    if (mysqli_query($conn, $sql)) {
        header("Location: admin.php?deleted=1");
    } else {
        echo "Σφάλμα κατά τη διαγραφή: " . mysqli_error($conn);
    }
}
?>
