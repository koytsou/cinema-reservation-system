<?php
session_start();

// Σύνδεση με τη βάση δεδομένων
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cinema";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Έλεγχος αν υπάρχουν τα απαραίτητα δεδομένα
    if (isset($_POST['reservation_date'], $_POST['reservation_time'], $_POST['seat_number'], $_POST['movie_id']) && isset($_SESSION['user_id'])) {
        $reservation_date = $_POST['reservation_date'];
        $reservation_time = $_POST['reservation_time'];
        $seat_numbers = $_POST['seat_number'];
        $movie_id = $_POST['movie_id'];
        $user_id = $_SESSION['user_id']; // Το user ID από το session

        foreach ($seat_numbers as $seat) {
            // Έλεγχος αν η θέση είναι ήδη κρατημένη
            $check_stmt = $conn->prepare("SELECT COUNT(*) FROM reservations WHERE reservation_date = :reservation_date AND reservation_time = :reservation_time AND seat_number = :seat_number AND movie_id = :movie_id");
            $check_stmt->bindParam(':reservation_date', $reservation_date);
            $check_stmt->bindParam(':reservation_time', $reservation_time);
            $check_stmt->bindParam(':seat_number', $seat);
            $check_stmt->bindParam(':movie_id', $movie_id);
            $check_stmt->execute();

            $existing_reservations = $check_stmt->fetchColumn();

            if ($existing_reservations > 0) {
                // Ειδοποίηση ότι η θέση είναι ήδη κρατημένη
                echo "<script>
                        alert('Η θέση $seat είναι ήδη κρατημένη για τη συγκεκριμένη ταινία, ημερομηνία και ώρα.');
                        window.location.href = 'movie.php?id=$movie_id';
                      </script>";
                exit; // Τερματισμός για να μην προχωρήσει η διαδικασία
            }

            // Αν η θέση δεν είναι κρατημένη, καταχώρηση στη βάση
            $stmt = $conn->prepare("INSERT INTO reservations (reservation_date, reservation_time, seat_number, movie_id, u_id) VALUES (:reservation_date, :reservation_time, :seat_number, :movie_id, :user_id)");
            $stmt->bindParam(':reservation_date', $reservation_date);
            $stmt->bindParam(':reservation_time', $reservation_time);
            $stmt->bindParam(':seat_number', $seat);
            $stmt->bindParam(':movie_id', $movie_id);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
        }

        // Μήνυμα επιβεβαίωσης
        echo "<script>
                alert('Η κράτησή σας καταχωρήθηκε με επιτυχία!');
                window.location.href = 'movie.php?id=$movie_id';
              </script>";
    } else {
        // Ειδοποίηση σφάλματος με alert και ανακατεύθυνση
        echo "<script>
                alert('Σφάλμα! Δεν δόθηκαν τα απαραίτητα στοιχεία για την κράτηση.');
                window.location.href = 'movie.php?id=$movie_id';
              </script>";
    }
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>