<?php
session_start();

// Σύνδεση με τη βάση δεδομένων
$host = 'localhost';
$dbname = 'cinema';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Λήψη του id από το URL
    $movie_id = $_GET['id'];

    // Ερώτημα για την ταινία
    $stmt = $conn->prepare("SELECT * FROM movies WHERE id = :id");
    $stmt->bindParam(':id', $movie_id, PDO::PARAM_INT);
    $stmt->execute();
    $movie = $stmt->fetch(PDO::FETCH_ASSOC);

    // Έλεγχος αν υπάρχει η ταινία
    if (!$movie) {
        die("Η ταινία δεν βρέθηκε.");
    }

    // Αν ο χρήστης έχει υποβάλει ημερομηνία και ώρα
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['date'], $_POST['time'])) {
        $selected_date = $_POST['date'];
        $selected_time = $_POST['time'];

        // Εύρεση κρατημένων θέσεων
        $stmt = $conn->prepare(
            "SELECT seat_number FROM reservations 
            WHERE movie_id = :movie_id AND date = :date AND time = :time"
        );
        $stmt->bindParam(':movie_id', $movie_id, PDO::PARAM_INT);
        $stmt->bindParam(':date', $selected_date, PDO::PARAM_STR);
        $stmt->bindParam(':time', $selected_time, PDO::PARAM_STR);
        $stmt->execute();

        $reserved_seats = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
} catch (PDOException $e) {
    die("Σφάλμα: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Cinema</title>
    <link rel="stylesheet" href="Css/style.css">
    <link rel="stylesheet" href="Css/StyleMovies.css">
    <script src="trailer-modal.js"></script>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .user-image {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-bottom: 5px;
        }

        .red-box {
            color: white;
            background-color: red;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .loginborder {
            border: 1px solid red;
        } 
        
    
    </style>
    
</head>
  <body class="contact-page blur ">
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CinemaVenia</label>
        <ul>
            <li><a class="active" href="main.php">Aρχική</a></li>
            <li><a href="Ταινιες.php">Ταινιες</a></li>
            <li><a href="Προσεχως.php">Προσεχως</a></li>
            <li><a href="Επικοινωνια.php">Επικοινωνια</a></li>
            <?php
            // Έλεγχος αν ο χρήστης είναι admin
            if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
                echo '<li><a href="admin.php" ">Admin Panel</a></li>';
            }
            ?>
             <?php
            
            if (isset($_SESSION['user_name'])) {
                echo '<li class="user-profile">
                    <img src="images/userprofile.png" alt="User Image" class="user-image">
                    <span>' . $_SESSION['user_name'] . '</span>
                    </li>';
                echo '<li><a href="destroy.php" class="red-box">Logout</a></li>';
            } else {
                echo '<li><a class="red-box loginborder" href="loginSite.php">Login</a></li>';
            }
            ?>
        </ul>
    </nav>
            <div class="movie-details-container">
                <!-- Αριστερό Τμήμα -->
                <div class="left-section">
                    <div class="movie-header">
                        <h1 class="movie-title"><?= $movie['title'] ?></h1>
                        <img class="movie-rating" src="data:image/jpeg;base64,<?= base64_encode($movie['rating']) ?>" alt="Rating" />
                    </div>
                    <p class="movie-description"><?= $movie['description'] ?></p>
                    <p class="movie-category"><strong>Κατηγορίες:</strong> <?= $movie['category'] ?></p>

                    <!-- Κουμπί για το Τρέιλερ -->
                    <?php if (!empty($movie['trailer'])): ?>
                        <button class="trailer-button" onclick="showTrailer()">Δείτε το Τρέιλερ</button>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['user_name'])): ?>        
                    <!-- Κουμπί για την Κράτηση -->
                    <button class="reservation-button" onclick="showReservationModal()">Κάντε Κράτηση</button>
                    <?php else: ?>
                                <p>Παρακαλώ συνδεθείτε για να κάνετε κράτηση.</p>
                    <?php endif; ?>
                </div>

                <!-- Modal για Κράτηση -->
                <div id="reservationModal" class="modal">
                    <div class="modal-content">
                        <!-- Κουμπί κλεισίματος -->
                        <span class="close" onclick="closeReservationModal()">&times;</span>

                        <h2>Κράτηση Θέσης</h2>
                        <form action="process_reservation.php" method="POST">
                                <!-- Απόκρυφα πεδία για movie_id και u_id -->
                                <input type="hidden" name="movie_id" value="<?= $movie_id; ?>">
                                <input type="hidden" name="u_id" value="<?= $_SESSION['user_id']; ?>">

                                <!-- Ημερομηνία -->
                                <label for="reservation_date">Ημερομηνία:</label>
                                <input type="date" id="reservation_date" name="reservation_date" min="2025-05-26" max="2025-06-17" required>

                                <!-- Ώρα -->
                                <label for="reservation_time">Ώρα:</label>
                                <select id="reservation_time" name="reservation_time" required>
                                    <option value="18:00">18:00</option>
                                    <option value="20:00">20:00</option>
                                    <option value="23:00">23:00</option>
                                </select>

                                <!-- Θέσεις -->
                                <label>Επιλέξτε Θέσεις:</label>
                                <div class="seat-selection">
                                    <?php for ($row = 1; $row <= 7; $row++): ?>
                                        <div class="seat-row">
                                            <?php for ($col = 1; $col <= 5; $col++): ?>
                                                <label>
                                                    <input type="checkbox" name="seat_number[]" value="R<?= $row ?>C<?= $col ?>">
                                                    R<?= $row ?>C<?= $col ?>
                                                </label>
                                            <?php endfor; ?>
                                        </div>
                                    <?php endfor; ?>
                                </div>

                                <!-- Κουμπιά Υποβολής και Ακύρωσης -->
                                <div class="modal-buttons">
                                    <button type="submit" class="reservation-button">Κάντε Κράτηση</button>
                                    <button type="button" class="cancel-button" onclick="closeReservationModal()">Ακύρωση</button>
                                </div>
                            </form>
                    </div>
                </div>
                

                <!-- Modal για το Trailer -->
                <div id="trailer-modal" class="trailer-modal">
                    <div class="trailer-content">
                        <span class="close" onclick="closeTrailer()">&times;</span>
                        <?php if (filter_var($movie['trailer'], FILTER_VALIDATE_URL)): ?>
                            <!-- YouTube ή άλλο URL -->
                            <iframe id="trailer-video" src="<?= $movie['trailer'] ?>" frameborder="0" allowfullscreen></iframe>
                        <?php else: ?>
                            <!-- Τοπικό αρχείο -->
                            <video id="trailer-video" controls>
                                <source src="path/to/trailers/<?= $movie['trailer'] ?>" type="video/mp4">
                                Ο περιηγητής σας δεν υποστηρίζει την αναπαραγωγή βίντεο.
                            </video>
                        <?php endif; ?>
                    </div>
                </div>


                <!-- Δεξί Τμήμα -->
                <div class="right-section">
                    <img class="movie-image" src="data:image/jpeg;base64,<?= base64_encode($movie['image_url']) ?>" alt="<?= $movie['title'] ?>" />
                </div>
            </div>
      
    </body>
</html>