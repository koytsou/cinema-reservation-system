<?php
session_start();
$host = 'localhost';
$dbname = 'cinema';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Έλεγχος για το ID
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        die("Το ID της ταινίας είναι άκυρο.");
    }
    $movie_id = $_GET['id'];

    // Ερώτημα για την ταινία
    $stmt = $conn->prepare("SELECT * FROM shortly WHERE id = :id");
    $stmt->bindParam(':id', $movie_id, PDO::PARAM_INT);
    $stmt->execute();
    $movie = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$movie) {
        die("Η ταινία δεν βρέθηκε.");
    }
} catch (PDOException $e) {
    die("Σφάλμα στη σύνδεση με τη βάση δεδομένων: " . $e->getMessage());
}
?>
    <!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Cinema</title>
    <link rel="stylesheet" href="Css/style.css">
    <link rel="stylesheet" href="Css/StyleMovies.css">
    <script src="trailer-modal.js"></script>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .user-image {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-bottom: 5px;
        }

        .red-box {
            color: white;
            background-color: red;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .loginborder {
            border: 1px solid red;
        } 
        
    
    </style>
    
</head>
  <body class="contact-page blur ">
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CinemaVenia</label>
        <ul>
            <li><a class="active" href="main.php">Aρχική</a></li>
            <li><a href="Ταινιες.php">Ταινιες</a></li>
            <li><a href="Προσεχως.php">Προσεχως</a></li>
            <li><a href="Επικοινωνια.php">Επικοινωνια</a></li>
             <?php
            
            if (isset($_SESSION['user_name'])) {
                echo '<li class="user-profile">
                    <img src="images/userprofile.png" alt="User Image" class="user-image">
                    <span>' . $_SESSION['user_name'] . '</span>
                    </li>';
                echo '<li><a href="destroy.php" class="red-box">Logout</a></li>';
            } else {
                echo '<li><a class="red-box loginborder" href="loginSite.php">Login</a></li>';
            }
            ?>
        </ul>
    </nav>
            <div class="movie-details-container">
                <!-- Αριστερό Τμήμα -->
                <div class="left-section">
                    <div class="movie-header">
                        <h1 class="movie-title"><?= $movie['title'] ?></h1>
                        <img class="movie-rating" src="data:image/jpeg;base64,<?= base64_encode($movie['rating']) ?>" alt="Rating" />
                    </div>
                    <p class="movie-description"><?= $movie['description'] ?></p>
                    <p class="movie-category"><strong>Κατηγορίες:</strong> <?= $movie['category'] ?></p>

                    <!-- Κουμπί για το Τρέιλερ -->
                    <?php if (!empty($movie['trailer'])): ?>
                        <button class="trailer-button" onclick="showTrailer()">Δείτε το Τρέιλερ</button>
                    <?php endif; ?>
                 </div>       
                <!-- Modal για το Trailer -->
                <div id="trailer-modal" class="trailer-modal">
                    <div class="trailer-content">
                        <span class="close" onclick="closeTrailer()">&times;</span>
                        <?php if (filter_var($movie['trailer'], FILTER_VALIDATE_URL)): ?>
                            <!-- YouTube ή άλλο URL -->
                            <iframe id="trailer-video" src="<?= $movie['trailer'] ?>" frameborder="0" allowfullscreen></iframe>
                        <?php else: ?>
                            <!-- Τοπικό αρχείο -->
                            <video id="trailer-video" controls>
                                <source src="path/to/trailers/<?= $movie['trailer'] ?>" type="video/mp4">
                                Ο περιηγητής σας δεν υποστηρίζει την αναπαραγωγή βίντεο.
                            </video>
                        <?php endif; ?>
                    </div>
                </div>


                <!-- Δεξί Τμήμα -->
                <div class="right-section">
                    <img class="movie-image" src="data:image/jpeg;base64,<?= base64_encode($movie['image_url']) ?>" alt="<?= $movie['title'] ?>" />
                </div>
            </div>        
      
    </body>
</html>