<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Cinema</title>
    <link rel="stylesheet" href="Css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .user-image {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-bottom: 5px;
        }

        .red-box {
            color: white;
            background-color: red;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .loginborder {
            border: 1px solid red;
        } 
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            max-width: 600px;
            padding: 20px;
        }

        .admin-form {
            background-color: #1e1e1e;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
        }

        .admin-form h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #b22222; /* Βαθύ κόκκινο */
        }

        .admin-form label {
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
            color: #f5f5f5;
        }

        .admin-form input, 
        .admin-form textarea, 
        .admin-form button {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .admin-form input, 
        .admin-form textarea {
            background-color: #2c2c2c;
            color: #f5f5f5;
        }

        .admin-form textarea {
            resize: none;
            height: 100px;
        }

        .admin-form button {
            background-color: #8b0000; /* Βαθύ κόκκινο */
            color: #f5f5f5;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .admin-form button:hover {
            background-color: #a40000; /* Ελαφρώς φωτεινότερο βαθύ κόκκινο */
        }

        /* Responsive Στυλ */
        @media (max-width: 768px) {
            .admin-form {
                padding: 20px;
            }

            .admin-form h2 {
                font-size: 24px;
            }

            .admin-form input,
            .admin-form textarea,
            .admin-form button {
                font-size: 14px;
                padding: 10px;
            }
        }
    </style>
    
</head>
  <body class="contact-page blur ">
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CinemaVenia</label>
        <ul>
            <li><a class="active" href="main.php">Aρχική</a></li>
            <li><a href="Ταινιες.php">Ταινιες</a></li>
            <li><a href="Προσεχως.php">Προσεχως</a></li>
            <li><a href="Επικοινωνια.php">Επικοινωνια</a></li>
            <?php
            // Έλεγχος αν ο χρήστης είναι admin
            if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
                echo '<li><a href="admin.php" ">Admin Panel</a></li>';
            }
            ?>
             <?php
            session_start();
            if (isset($_SESSION['user_name'])) {
                echo '<li class="user-profile">
                    <img src="images/userprofile.png" alt="User Image" class="user-image">
                    <span>' . $_SESSION['user_name'] . '</span>
                    </li>';
                echo '<li><a href="destroy.php" class="red-box">Logout</a></li>';
            } else {
                echo '<li><a class="red-box loginborder" href="loginSite.php">Login</a></li>';
            }
            ?>
        </ul>
    </nav>
      <div class="container">
        <div class="admin-form">
            <h2>Προσθήκη Νέας Ταινίας</h2>
            <form method="POST" action="insert_movie.php" enctype="multipart/form-data">
                <label for="title">Τίτλος Ταινίας:</label>
                <input type="text" id="title" name="title" required>
                
                <label for="description">Περιγραφή:</label>
                <textarea id="description" name="description" required></textarea>
                
                <label for="image_url">Εικόνα:</label>
                <input type="file" id="image_url" name="image_url" required>
                
                <label for="rating">Εικόνα Βαθμολογίας:</label>
                <input type="file" id="rating" name="rating" required>
                
                <label for="category">Κατηγορία:</label>
                <input type="text" id="category" name="category" required>
                
                <label for="trailer">URL Τρέιλερ:</label>
                <input type="url" id="trailer" name="trailer" required>
                
                <button type="submit">Προσθήκη</button>
            </form>
        </div>
    </div>
      <div class="container">
        <div class="admin-form">
            <h2>Προσθήκη στον Πίνακα Shortly</h2>
            <form method="POST" action="insert_shortly.php" enctype="multipart/form-data">
                <label for="title_shortly">Τίτλος:</label>
                <input type="text" id="title_shortly" name="title" required>
                
                <label for="description_shortly">Περιγραφή:</label>
                <textarea id="description_shortly" name="description" required></textarea>
                
                <label for="image_url_shortly">Εικόνα:</label>
                <input type="file" id="image_url_shortly" name="image_url" required>
                
                <label for="rating_shortly">Εικόνα Βαθμολογίας:</label>
                <input type="file" id="rating_shortly" name="rating" required>
                
                <label for="category_shortly">Κατηγορία:</label>
                <input type="text" id="category_shortly" name="category" required>
                
                <label for="trailer_shortly">URL Τρέιλερ:</label>
                <input type="url" id="trailer_shortly" name="trailer" required>
                
                <button type="submit">Προσθήκη</button>
            </form>
        </div>
    </div>
      <?php
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
    include 'db_connection.php';
    $result = mysqli_query($conn, "SELECT id, title, category FROM movies");
    
    echo '<div class="container"><div class="admin-form">';
    echo '<h2>Διαγραφή Ταινιών</h2>';
    echo '<table class="table table-dark table-striped">';
    echo '<thead><tr><th>Τίτλος</th><th>Κατηγορία</th><th>Ενέργεια</th></tr></thead><tbody>';
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['title']}</td>
                <td>{$row['category']}</td>
                <td><a href='delete_movie.php?id={$row['id']}' class='btn btn-danger' onclick='return confirm(\"Σίγουρα θες να διαγράψεις αυτήν την ταινία;\")'>Διαγραφή</a></td>
              </tr>";
    }

    echo '</tbody></table></div></div>';
}
?>
<?php
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
    include 'db_connection.php';
    $result = mysqli_query($conn, "SELECT id, title, category FROM shortly");

    echo '<div class="container"><div class="admin-form">';
    echo '<h2>Διαγραφή Ταινιών (Προσεχώς)</h2>';
    echo '<table class="table table-dark table-striped">';
    echo '<thead><tr><th>Τίτλος</th><th>Κατηγορία</th><th>Ενέργεια</th></tr></thead><tbody>';

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['title']}</td>
                <td>{$row['category']}</td>
                <td><a href='delete_shortly.php?id={$row['id']}' class='btn btn-danger' onclick='return confirm(\"Σίγουρα θες να διαγράψεις αυτήν την ταινία;\")'>Διαγραφή</a></td>
              </tr>";
    }

    echo '</tbody></table></div></div>';
}
?>


      
     </body>
</html> 